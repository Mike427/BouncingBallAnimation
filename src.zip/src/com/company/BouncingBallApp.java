package com.company;

import javax.swing.JFrame;


public class BouncingBallApp extends JFrame {

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Set the appropriate Window Closing Features
        frame.add(new BouncingBallPanel());
        frame.addMouseListener(new BouncingBallPanel());//Make the BBP the "MouseListener" object
        frame.setSize(400, 400);//set window size
        frame.setVisible(true);//make window visible
    }

}
