package com.company;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class BouncingBallPanel extends JPanel implements MouseListener{
    //private int ballCount;
    private Ball[] ballArray;
    private final BouncingBallPanel bouncingBallPanel;

    public BouncingBallPanel() {
        ballArray  = new Ball[20];
        bouncingBallPanel = null;
    }


    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
        Thread thread = new Thread();
        Ball newBall = new Ball(bouncingBallPanel);//create new Ball
        ballArray[1] = newBall;
        thread.start();
        /*if(ballCount==1){
            //Start the thread
        }*/
    }
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        for (Ball ball:ballArray){
            g.fillOval(0, 0, 30, 30);
        }
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }
}
