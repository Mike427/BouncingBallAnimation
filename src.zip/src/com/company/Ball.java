package com.company;

import java.awt.Color;


public class Ball implements Runnable {
    private final BouncingBallPanel bouncingBallPanel;
    private double x;
    private double y;
    private double diameter;
    private Color color;
    private int deltaX;
    private int deltaY;

    public Ball(BouncingBallPanel bouncingBallPanel) {
        this.bouncingBallPanel=bouncingBallPanel;
    }

    @Override
    public void run() {
        int randomDelay = (int)(Math.random());
        while (true){
            move();
            bouncingBallPanel.repaint();
            try {
                Thread.sleep(randomDelay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public void move() {
        x = x + deltaX;
        y = y + deltaY;
        double panelWidth = 0;
        double panelHeight = 0;
        if (x > panelWidth) {
            deltaX = -deltaX; // cause ball to move in opposite x direction
        }
        
        if (y > panelHeight) {
            deltaY = -deltaY; // cause ball to move in opposite y direction
        }
    }
}
